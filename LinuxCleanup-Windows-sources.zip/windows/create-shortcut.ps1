$ErrorActionPreference = 'Stop'
$Executable = Join-Path $PSScriptRoot 'clarisweep.exe'
if (-not (Test-Path $Executable)) { throw 'Place this script next to the packaged clarisweep.exe.' }
$Shell = New-Object -ComObject WScript.Shell
foreach ($Directory in @([Environment]::GetFolderPath('Desktop'),[Environment]::GetFolderPath('Programs'))) {
    $Link = $Shell.CreateShortcut((Join-Path $Directory 'Linux Cleanup.lnk'))
    $Link.TargetPath = $Executable
    $Link.WorkingDirectory = $PSScriptRoot
    $Link.Description = 'Disk space and application cache manager'
    $Link.Save()
}
Write-Host 'Shortcuts created on Desktop and Start menu. Right-click the shortcut to pin it to the taskbar.'
