# Linux Cleanup — port Windows

Code adapté pour Windows x64. Compilation et exécution Windows pas encore validées : développement effectué sous Linux, sans kit Qt Windows disponible.

## Générer programme

Sur Windows, installer Visual Studio 2022 (module Développement Desktop en C++, incluant CMake) et Qt 6, kit MSVC 2022 64-bit.

Ouvrir **Developer PowerShell for VS 2022**, puis dans dossier source :

```powershell
.\windows\build-windows.ps1 -QtRoot 'C:\Qt\6.8.3\msvc2022_64'
```

Remplacer chemin par celui du kit Qt installé. Script compile application, lance tests de filtrage, utilise windeployqt pour rassembler DLL/plugins et crée dossier portable + ZIP. Aucune élévation administrateur requise pour lancer application.

Source déploiement Qt : https://doc.qt.io/qt-6/windows-deployment.html

## Utiliser dossier portable

Extraire ZIP entier. Lancer **clarisweep.exe**. Ne pas déplacer uniquement EXE : DLL et dossier platforms nécessaires.

**create-shortcut.ps1** crée raccourcis Bureau et menu Démarrer pointant vers ce dossier. Déplacer le dossier portable ensuite casse les raccourcis. Clic droit sur raccourci pour épingler barre des tâches.

## Fonctionnalités adaptées

- Analyse automatique et identification Windows via Qt.
- Cache Internet du compte dans LOCALAPPDATA et anciens fichiers TEMP utilisateur.
- Applications : raccourcis .lnk du menu Démarrer avec icônes Windows. Ce n'est pas inventaire exhaustif des logiciels.
- Disques : lecteurs Windows, noms, espace utilisé/libre.
- Gros fichiers et paramètres Français/English.
- Cache Internet et fichiers temporaires analysés : suppression définitive des fichiers cochés après confirmation ; fichiers verrouillés peuvent échouer et sont comptés.
- Journaux système, miniatures et estimation corbeille : non pris en charge, aucun chiffre inventé. Bouton corbeille ouvre corbeille Windows.
- Paquets : ouvre Paramètres Applications Windows. Aucun désinstalleur automatique.
- Jonctions, liens et fichiers à points de réanalyse ignorés.

## Vérifier sur Windows

Après génération, lancer EXE, vérifier analyse, lecteurs, raccourcis et bascule de langue. Tester nettoyage avec des fichiers sans importance uniquement.
Le script exécute tests automatiques de filtres mais ne constitue pas validation complète de Windows ni de la corbeille.
