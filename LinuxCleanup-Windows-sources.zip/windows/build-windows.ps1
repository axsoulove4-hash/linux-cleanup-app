param(
    [Parameter(Mandatory=$true)][string]$QtRoot
)
$ErrorActionPreference = 'Stop'
# Run from Developer PowerShell for Visual Studio 2022.
$ProjectRoot = Split-Path $PSScriptRoot -Parent
$BuildRoot = Join-Path $ProjectRoot 'build-windows'
$DeployTool = Join-Path $QtRoot 'bin/windeployqt.exe'
if (-not (Test-Path $DeployTool)) { throw "QtRoot must point to the Qt MSVC x64 kit, containing bin/windeployqt.exe." }
foreach ($tool in @('cmake','cl')) {
    if (-not (Get-Command $tool -ErrorAction SilentlyContinue)) { throw "Missing $tool. Use Developer PowerShell for VS 2022 with Desktop development with C++ installed." }
}
function Checked([string]$program, [string[]]$arguments) {
    & $program @arguments
    if ($LASTEXITCODE -ne 0) { throw "$program failed: $LASTEXITCODE" }
}
Checked 'cmake' @('-S',$ProjectRoot,'-B',$BuildRoot,'-G','Visual Studio 17 2022','-A','x64',"-DCMAKE_PREFIX_PATH=$QtRoot")
Checked 'cmake' @('--build',$BuildRoot,'--config','Release','--parallel')
$OldPath = $env:PATH
try {
    $env:PATH = (Join-Path $QtRoot 'bin') + ';' + $OldPath
    Checked 'ctest' @('--test-dir',$BuildRoot,'-C','Release','--output-on-failure')
} finally { $env:PATH = $OldPath }
# A unique output preserves previous packages.
$PackageRoot = Join-Path $ProjectRoot ('LinuxCleanup-Windows-' + (Get-Date -Format 'yyyyMMdd-HHmmss'))
New-Item -ItemType Directory -Path $PackageRoot | Out-Null
Copy-Item (Join-Path $BuildRoot 'Release/clarisweep.exe') $PackageRoot
Copy-Item (Join-Path $PSScriptRoot 'create-shortcut.ps1') $PackageRoot
Copy-Item (Join-Path $PSScriptRoot 'README-Windows.md') $PackageRoot
Checked $DeployTool @('--release','--compiler-runtime',(Join-Path $PackageRoot 'clarisweep.exe'))
Compress-Archive -Path $PackageRoot -DestinationPath ($PackageRoot + '.zip')
Write-Host "Ready: $PackageRoot"
Write-Host "Run clarisweep.exe. Keep the DLLs and plugins beside it."
